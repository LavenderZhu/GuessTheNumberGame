/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guessthenumbergame;

/**
 *
 * @author zhuming
 */
import javax.swing.JFrame;
import java.util.Random;
import java.lang.Math;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.SwingUtilities;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class GuessGameFrame extends JFrame {
    
    private Random generator;
    private int randomGenerator;
    private int guessCount=0;
    private int userInput;
    private int currentDistance;
    private int lastDistance;
    private JTextField userInputJTextField;
    private JLabel prompt1JLabel;
    private JLabel prompt2JLabel;
    private JLabel messageJLabel;
    private JButton newGameJButton;
    
    public GuessGameFrame() {
        super("Guessing Game");
        setLayout(new FlowLayout());
        
        generator = new Random();
        randomGenerator = 1 + generator.nextInt(1000);
        
        prompt1JLabel = new JLabel();
        prompt2JLabel = new JLabel();
        messageJLabel = new JLabel();
        
        userInputJTextField = new JTextField(5);
        userInputJTextField.setEditable(true);
        
        newGameJButton = new JButton();
        getContentPane().setBackground(Color.WHITE);
        
        prompt1JLabel.setText("I have a number between 1 and 1000. Can you guess my number?");
        messageJLabel.setText("Guess Result:");
        newGameJButton.setText("New Game");
        
        if (guessCount<1){
            prompt2JLabel.setText("Please enter your first guess.");
        }
        
        GuessGameFrameHandler handler = new GuessGameFrameHandler();
        userInputJTextField.addActionListener(handler);
        NewGuessGameFrameHandler newGameHandler = new NewGuessGameFrameHandler();
        newGameJButton.addActionListener(newGameHandler);
        
        add(prompt1JLabel);
        add(prompt2JLabel);
        add(userInputJTextField);
        add(messageJLabel);
        add(newGameJButton);
        
    }
    
    private class GuessGameFrameHandler implements ActionListener {
        @Override
        public void actionPerformed (ActionEvent event) {
            userInput = Integer.parseInt(userInputJTextField.getText());
            
            guessCount+=1;
            if (guessCount>0){
            prompt2JLabel.setText("Please enter your guess.");
            }
            
            currentDistance = Math.abs(userInput - randomGenerator);
            

            if (currentDistance>lastDistance){
                getContentPane().setBackground(Color.BLUE);
            }
            else if (currentDistance<lastDistance){
                getContentPane().setBackground(Color.RED);
            }
            else {
                getContentPane().setBackground(Color.WHITE);
            }
            
            lastDistance = currentDistance;
            
            if (userInput == randomGenerator){
                getContentPane().setBackground(Color.GREEN);
                prompt1JLabel.setText("You got the correct number!");
                prompt2JLabel.setText("Start new game?");
                messageJLabel.setText("correct");
                SwingUtilities.updateComponentTreeUI(messageJLabel);
                userInputJTextField.setEditable(false);
            }
            else if (userInput>randomGenerator){
                messageJLabel.setText("too high");
                SwingUtilities.updateComponentTreeUI(messageJLabel);
            }
            else if (userInput<randomGenerator){
                messageJLabel.setText("too low");
                SwingUtilities.updateComponentTreeUI(messageJLabel);
            }

        }
    
    }
    
    private class NewGuessGameFrameHandler implements ActionListener {
        @Override
        public void actionPerformed (ActionEvent event) {
            generator = new Random();
            randomGenerator = 1 + generator.nextInt(1000);
            getContentPane().setBackground(Color.WHITE);
            guessCount = 0;
            currentDistance = 0;
            lastDistance = 0;
            prompt1JLabel.setText("I have a number between 1 and 1000. Can you guess my number?");
            messageJLabel.setText("Guess Result:");
            newGameJButton.setText("New Game");
            prompt2JLabel.setText("Please enter your first guess.");
            userInputJTextField.setText("");
            userInputJTextField.setEditable(true);
        
        }
    
    }
    

    
}
