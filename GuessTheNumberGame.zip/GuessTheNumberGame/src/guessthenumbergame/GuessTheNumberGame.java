/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guessthenumbergame;

/**
 *
 * @author zhuming
 */
import javax.swing.JFrame;

public class GuessTheNumberGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        GuessGameFrame guessGameFrame = new GuessGameFrame();
        guessGameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        guessGameFrame.setSize(500, 200);
        guessGameFrame.setVisible(true);
    }
    
}
